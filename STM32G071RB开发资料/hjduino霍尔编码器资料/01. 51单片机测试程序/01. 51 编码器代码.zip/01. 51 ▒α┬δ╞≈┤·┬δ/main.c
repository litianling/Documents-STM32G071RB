#include <stdio.h>
#include <reg52.h>

# define uchar unsigned char
# define uint unsigned int

int i=0;

void initEx0();

sbit motorB = P3^4;
sbit LED = P1^0;
 
uint count = 0;
 
 void delay(unsigned int i){
	while(i--);
}
 
void InitUART(void) 
{
    TH1 = 0xFD;	 //??11.0592mhz ?????9600
    TL1 = TH1;
    TMOD |= 0x20;	  
    SCON = 0x50;	 
    ES = 1;			  
    TR1 = 1;		 
    TI = 1;    
		PS = 0;
	  EA = 1;	  	 
}

void main()
{
    InitUART(); 
	  initEx0();
		motorB = 1;
	
    while(1)
    {
        LED = 1;
				delay(60000);
				LED = 0;
				delay(60000);
    }
}

//P32
void initEx0() {
  EA = 1;	  
  EX0 = 1;	 
  IT0 = 1;	
	PX0 = 1;	
}

void ex0_intr() interrupt 0 { 
		  if(motorB == 1){
				i++;
			}else{
				i--;
			}
	LED = 0;
	printf("%d\n", i);
}

