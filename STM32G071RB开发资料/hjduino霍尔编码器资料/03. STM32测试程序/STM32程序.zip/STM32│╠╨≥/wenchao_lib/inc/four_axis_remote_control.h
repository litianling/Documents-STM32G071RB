/**
  ******************************************************************************
  * @file    four_axis_remote_control.h
  * @author  ���ĳ� 
	* @qq      269426626
  * @version V1.0
  * @date    2016.9.10
  * @note    �˳���Ϊ����Ӧ�ñ��
  ******************************************************************************
  */
#ifndef __CH_LIB_FOUR_AXIS_REMOTE_CONTROL_H__
#define __CH_LIB_FOUR_AXIS_REMOTE_CONTROL_H__

#ifdef __cplusplus
 extern "C" {
#endif

#include "sysinc.h"

#endif
